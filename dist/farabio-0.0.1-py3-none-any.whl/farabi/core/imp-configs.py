from farabio.core.configs import get_config

config, unparsed = get_config('srgan')



# def add_argument_group(_subparser, _groupname):
#     arg = _subparser.add_argument_group(_groupname)
#     _arglists.append(arg)
#     return arg

# def add_argument_group(_subparser, name):
#     arg = _subparser.add_argument_group(name)
#     _arglists.append(arg)
#     return arg